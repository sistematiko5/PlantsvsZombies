package tp.p1;
public class SuncoinManager {
	private int suncoins = 50;
	
	public boolean comprado(int valor) {
		if(valor <= suncoins) {
			suncoins = suncoins - valor;
			return true;
		}
		return false;
	}
	
	public int getSuncoin() {
		return this.suncoins;
	}
	
	public void setSuncoins(int newSuncoins) {
		this.suncoins = newSuncoins;
	}
}
