package tp.p1;
import java.util.Random;


public class ZombieManager {
	
	private int random;
	
	public boolean crearZombie(Random seed, Level nivel){
		int intNivel = 0;
		random = seed.nextInt();
		random = Math.abs(random);
		switch(nivel) {
		case EASY:
			intNivel = 10;// Al hacer el modulo de rand sobre 10 la posibilidad de que sea ==1 es de 1/10 = 0,1
			break;
		case HARD:
			intNivel = 5;// Al hacer el modulo de rand sobre 10 la posibilidad de que sea ==1 es de 1/5 = 0,2
			break;
		case INSANE:
			intNivel = 3;// Al hacer el modulo de rand sobre 10 la posibilidad de que sea ==1 es de 1/3 = 0,33
			break;
		case ERROR:
			System.out.println("error");
			intNivel = 0;
			break;
		}
		return (random % intNivel == 1);
	}
	
	public int getPosX(Random rand, int tamX) {
		random = rand.nextInt();
		random =Math.abs(random);
		return(random % tamX);// El modulo tamX va de 0 a (tamX - 1), que son las posibles filas del tablero
	}
	

}
