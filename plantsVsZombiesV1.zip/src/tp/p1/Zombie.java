package tp.p1;

public class Zombie {
	private int vida;
	private int da�o;
	private int velocidad;
	private int fila;
	private int columna;
	private Game game;
	private int contMovimiento = 0;
	
	public Zombie(int fila, int columna, Game game)
	{
		this.columna = columna;
		this.da�o = 1;
		this.fila = fila;
		this.velocidad = 1;
		this.vida = 5;
		this.setGame(game);
	}
	public int getVida() {
		return this.vida;
	}
	public int getFila() {
		return this.fila;
	}
	public int getColumna() {
		return this.columna;
	}
	public int getDa�o() {
		return this.da�o;
	}
	public int getVelocidad() {
		return this.velocidad;
	}
	
	public void setVida(int nuevaVida) {
		this.vida = nuevaVida;
	}
	public void setColumna(int nuevaColumna) {
		this.columna = nuevaColumna;
	}
	public void setFila(int nuevafila) {
		this.fila = nuevafila;
	}
	
	public Game getGame() {
		return game;
	}
	public void setGame(Game game) {
		this.game = game;
	}
	public void update() {
		
		if(game.vacio(fila, columna-1)) //Si la posicion siguiente esta vacia avanza
		{
			if(contMovimiento == 1) {
				setColumna(columna - 1);
				contMovimiento = 0;
			}
			else {
				contMovimiento++;
			}
			
		}
		else if((game.buscaFlores(fila, columna-1)) != -1) //Si en la posicion siguiente hay un sunflower ataca
		{
			game.restarVidaSunflower(fila, columna - 1);
		}
		else if((game.buscaShooters(fila, columna-1)) != -1) //Si en la posicion siguiente hay un peashooter ataca
		{
			game.restarVidaPeashooter(fila, columna - 1);
		}
		
	}
	
	public String toString() {
		String stringZombie;
		stringZombie = "Z [" + this.vida + "]";
		return stringZombie;
	}

}
