package tp.p1;
//import java.util.Random;
import java.util.Scanner;



public class CommandScanner {
	private String command = "";
	private String plant;
	private String aux;
	private int x, y;
	private Scanner entradaEscaner = new Scanner(System.in);
	
	public CommandScanner(){
		
	}
	public String setCommand(){
		System.out.println("Command > ");
		command = entradaEscaner.nextLine();
		aux = command.split(" ")[0].trim();
		//Comprueba cual es el command que se ha introducido y lo guarda en el String command
		if((aux.equalsIgnoreCase("add") )|| aux.equalsIgnoreCase("A")||aux.equalsIgnoreCase("aeasy")) {
			plant = command.split(" ")[1].trim();
			x = Integer.parseInt(command.split(" ")[2].trim()); // Convierte la tercera palabra del string command en un int para tener la posicion X en la que se quiere insertar la planta
			y = Integer.parseInt(command.split(" ")[3].trim()); // Convierte la tercera palabra del string command en un int para tener la posicion Y en la que se quiere insertar la planta
			command = "A";
		}
		else if((command.equalsIgnoreCase("reset") )|| command.equalsIgnoreCase("R")||command.equalsIgnoreCase("r")) {
			command = "R";
		}
		else if(command.equalsIgnoreCase("list")|| command.equalsIgnoreCase("L")||command.equalsIgnoreCase("l")) {
			command = "L";
		}
		else if(command.equalsIgnoreCase("none")|| command.equalsIgnoreCase("N")||command.equalsIgnoreCase("n") || command.equalsIgnoreCase("")) {
			command = "N";
		}
		else if(command.equalsIgnoreCase("help")|| command.equalsIgnoreCase("H")||command.equalsIgnoreCase("h")) {
			command = "H";
		}
		else if(command.equalsIgnoreCase("exit")|| command.equalsIgnoreCase("E")||command.equalsIgnoreCase("e")) {
			command = "E";
		}
		else {
			command = "U";
		}
		return command;
	}
	public String getCommand() {
		return this.command;
	}
	public String getPlanta() {
		return this.plant;
	}
	public int getX() {
		return this.x;
	}
	public int getY() {
		return this.y;
	}
}
