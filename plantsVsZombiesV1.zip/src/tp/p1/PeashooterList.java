package tp.p1;

public class PeashooterList {
	private Peashooter PeashooterList[];
	private int contador = 0;
	private Game game;
	
	public PeashooterList(Game game, int MAX_TAM_TABLERO) {
		PeashooterList = new Peashooter[MAX_TAM_TABLERO];
		this.contador = 0;
		this.game = game;
	}
	
	public void addPeashooter(int fila, int columna)
	{
		this.PeashooterList[this.contador] = new Peashooter(fila, columna, game);
		this.contador++;
	}
	
	public void deletePeashooter(int posicion) {
		for (int i = posicion; i < contador; i ++) {
			this.PeashooterList[i] = this.PeashooterList[i + 1];
		}
		this.contador--;
	}
	
	public int getCont()
	{
		return this.contador;
	}
	public void setCont(int num)
	{
		this.contador = num;
	}
	public void restarVida(int x, int y) {
		int pos;
		pos = buscaShooters(x, y);
		this.PeashooterList[pos].setVida(this.PeashooterList[pos].getVida() - 1);
		if(this.PeashooterList[pos].getVida() == 0){
			deletePeashooter(pos);
		}
	}
	public void update(){
		for(int i = 0; i < this.contador; ++i){
			this.PeashooterList[i].update();
		}
	}
	public int buscaShooters(int fila, int columna)
	{
		for(int i = 0; i< this.contador; i++)
		{
			if(this.PeashooterList[i].getColumna() == columna && this.PeashooterList[i].getFila() == fila)
			{
				return i;
			}
		}
		return -1;
	}
	
	public String getString(int pos) {
		return this.PeashooterList[pos].toString();
	}
}
