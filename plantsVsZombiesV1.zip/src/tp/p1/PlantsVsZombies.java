package tp.p1;

import java.util.Random;
import tp.p1.Level;

public class PlantsVsZombies {
	public static void main(String [] args) {
		Random rand = new Random();
		rand = new Random();
		Level level = null;
		int ancho = 8, alto = 4;
		
		GamePrinter board = new GamePrinter();
		if(args.length != 1){
			System.out.println("Introduce el nivel en los argumentos");
		}
		else{
			if(args[0].equals("EASY")) level = Level.EASY;
			else if(args[0].equals("HARD")) level = Level.HARD;
			else if(args[0].equals("INSANE")) level = Level.INSANE;
		}
		
		Game game = new Game(rand, level);
		
		board.printer(game, alto, ancho);
		Controller controller = new Controller(game, board);
		controller.run();
	}
}
