package tp.p1;

public enum Level {
	EASY, HARD, INSANE, ERROR;	
	
	public static Level parse(String a) {
		if(a.equalsIgnoreCase("EASY")) {
			return EASY;
		}
		else if(a.equalsIgnoreCase("HARD")){
			return HARD;
		}
		else if(a.equalsIgnoreCase("INSANE")){
			return INSANE;
		}
		else
		{
			return ERROR;
		}
	}
	public int numZombies(Level nivel) {
		int numZombies = 0;
		switch(nivel) {
		case EASY:
			numZombies = 3;
			break;
		case HARD:
			numZombies = 5;
			break;
		case INSANE:
			numZombies = 10;
			break;
		case ERROR:
			numZombies = 0;
			break;
		}
		return numZombies;
	}

}
