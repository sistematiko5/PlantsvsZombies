package tp.p1;

public class Sunflower {
	private int vida;
	private int frecuencia;
	private int fila;
	private int columna;
	private int contadorCiclo;
	private static int coste = 20;
	private Game game;
	
	public Sunflower(int fila, int columna, Game game)
	 {
		this.vida = 1;
		this.frecuencia = 10;
		this.fila = fila;
		this.columna = columna;
		this.game = game;
	 }
	
	public int getVida() {
		return this.vida;
	}
	public int getFila() {
		return this.fila;
	}
	public int getColumna() {
		return this.columna;
	}
	public int getFrecuencia() {
		return this.frecuencia;
	}
	
	public void setVida(int nuevaVida) {
		this.vida = nuevaVida;
	}
	public void setColumna(int nuevaColumna) {
		this.columna = nuevaColumna;
	}
	public void setFila(int nuevafila) {
		this.fila = nuevafila;
	}
	public int generarSoles() {
		return this.frecuencia;
	}
	public int getContadorCiclo() {
		return contadorCiclo;
	}
	public void setContadorCiclo(int contadorCiclo) {
		this.contadorCiclo = contadorCiclo;
	}
	public static int getCoste() {
		return coste;
	}
	public Game getGame() {
		return game;
	}
	public void setGame(Game game) {
		this.game = game;
	}

	public void update() {
		if( this.contadorCiclo == 2)
		{
			game.getSuncoin().setSuncoins(game.getSuncoin().getSuncoin() + this.frecuencia);
			this.contadorCiclo = 0;
		}
		else {
			this.contadorCiclo++;
		}
	}
	
	public String toString() {
		String stringSunflower;
		stringSunflower = "S [" + this.vida + "]";
		return stringSunflower;
	}


	

}
