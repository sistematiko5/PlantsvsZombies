package tp.p1;

public class ZombieList {
	private Zombie ZombieList[];
	private int contador = 0;
	private Game game;
	private int contZombiesMuertos = 0;
	
	public ZombieList(Game game, int MAX_TAM_TABLERO) {
		ZombieList = new Zombie[MAX_TAM_TABLERO];
		this.contador = 0;
		this.game = game;
	}
	
	public void addZombie(int fila, int columna)
	{
		this.ZombieList[this.contador] = new Zombie(fila, columna, game);
		this.contador++;
	}
	
	public void deleteZombie(int posicion) {
		for (int i = posicion; i < contador; i ++) {
			this.ZombieList[i] = this.ZombieList[i + 1];
		}
		this.contador--;
	}
	
	public Zombie getZombie(int i) {
		return this.ZombieList[i];
	}
	
	public int getCont()
	{
		return this.contador;
	}
	public void setCont(int num)
	{
		this.contador = num;
	}
	public void update(){
		for(int i = 0; i < this.contador; ++i){
			this.ZombieList[i].update();
		}
	}

	public void restarVida(int x, int y) {
		int pos;
		pos = buscaZombies(x, y);
		this.ZombieList[pos].setVida(this.ZombieList[pos].getVida() - 1);
		if(this.ZombieList[pos].getVida() == 0){
			deleteZombie(pos);
			contZombiesMuertos++;
		}
	}
	
	public int buscaZombies(int fila, int columna)
	{
		for(int i = 0; i< this.contador; i++)
		{
			if(this.ZombieList[i].getColumna() == columna && this.ZombieList[i].getFila() == fila)
			{
				return i;
			}
		}
		return -1;
	}
	public int getcontZombiesMuertos()
	{
		return this.contZombiesMuertos;
	}
	
	public String getString(int pos) {
		return this.ZombieList[pos].toString();
	}

}
