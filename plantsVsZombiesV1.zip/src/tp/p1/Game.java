package tp.p1;
import java.util.Random;
public class Game {
	private Random rand;
	private Level nivel;
	private int numZombies;
	private int numCiclos = 0;
	private int MAX_TAM_TABLERO = 32;
	private ZombieList ZombieList = new ZombieList(this, MAX_TAM_TABLERO);
	private SunflowerList SunflowerList = new SunflowerList(this, MAX_TAM_TABLERO);
	private PeashooterList PeashooterList = new PeashooterList(this, MAX_TAM_TABLERO);
	private int dimX = 4, dimY = 8;
	private SuncoinManager suncoin = new SuncoinManager();
	private ZombieManager zomManager = new ZombieManager();
	
	public Game(Random seed, Level level) {
		  this.rand = seed;
		  this.nivel = level;
		  this.calcularNumZombies(level);
	}
	
	public void update() {	
		this.SunflowerList.update();
		this.PeashooterList.update();
		this.ZombieList.update();

		this.numCiclos++;
	}
	
	public int buscaZombies(int fila, int columna)
	{
		return ZombieList.buscaZombies(fila, columna);
	}
	
	public int buscaFlores(int fila, int columna)
	{
		return SunflowerList.buscaSunflowers(fila, columna);
	}
	
	public int buscaShooters(int fila, int columna)
	{
		return PeashooterList.buscaShooters(fila, columna);
	}
	
	public boolean vacio(int fila, int columna)
	{
		if(buscaShooters(fila, columna) == -1 && buscaFlores(fila, columna) == -1 && ZombieList.buscaZombies(fila, columna) == -1)
		{
			return true;
		}
		else return false;
	}
	
	public ZombieList getZombieList() {
		return this.ZombieList;
	}
	
	public SunflowerList getSunflowerList() {
		return this.SunflowerList;
	}

	public PeashooterList getPeashooterList() {
		return this.PeashooterList;
	}
	
	public int getDimX() {
		return this.dimX;
	}
	
	public int getDimY() {
		return this.dimY;
	}
	
	public int getCiclos() {
		return this.numCiclos;
	}
	
	public int getSoles() {
		return suncoin.getSuncoin();
	}
	
	public int calcularNumZombies(Level nivel) { //Inicializa el numero de zombies que se van a crear segun el nivel
		this.numZombies = nivel.numZombies(nivel);
		return numZombies;
	}
	
	public int getNumZombies() {
		return this.numZombies;
	}

	public void reset() { //Reinicia los valores del game
		
		for(int i = 0; i < this.ZombieList.getCont(); i++) {
			this.ZombieList.deleteZombie(0);
		}
		for(int i = 0; i < this.PeashooterList.getCont(); i++) {
			this.PeashooterList.deletePeashooter(0);
		}
		for(int i = 0; i < this.SunflowerList.getCont(); i++) {
			this.SunflowerList.deleteSunflower(0);
		}
		this.numZombies = calcularNumZombies(this.nivel);
		this.numCiclos = 0;
		this.suncoin.setSuncoins(50);
		this.ZombieList.setCont(0);
		this.SunflowerList.setCont(0);
		this.PeashooterList.setCont(0);
	    this.numCiclos = 0;
	    suncoin.setSuncoins(50);			
	}
	
	public boolean addSunflower(int x, int y) {
		boolean add = false;
		if (suncoin.comprado(Sunflower.getCoste())){
			add = this.SunflowerList.addSunflower(x, y);
		}
		else {
			System.out.println("No tienes suficientes suncoins");
		}
		return add;
	}
	
	public boolean addPeashooter(int x, int y) {
		boolean add = false;
		if (suncoin.comprado(Peashooter.getCoste())){
			if(this.comprobarPosicion(x, y) && this.vacio(x, y)) {
				this.PeashooterList.addPeashooter(x, y);
				add = true;
			}
		}
		else {
			System.out.println("No tienes suficientes suncoins");
		}
		return add;
	}
	
	public Level getNivel() {
		return this.nivel;
	}
	
	public Random getRandom() {
		return this.rand;
	}
	
	public void crearZombie(int posX) {
		this.ZombieList.addZombie(posX, this.dimY);
		this.numZombies--;
	}
	
	public boolean gananZombies() {
		boolean fin = false;
		int colZombie;
		for(int i = 0; i < this.ZombieList.getCont(); i++)	
		{
			colZombie = this.ZombieList.getZombie(i).getColumna();
			if(colZombie == 0) {
				fin = true;
			}
		}	
		return fin;
	}
	
	public boolean gananPlantas() {
		boolean fin = false;
		if(ZombieList.getcontZombiesMuertos() == 3 && nivel.equals(Level.EASY)) {
			fin = true;
		}
		else if(ZombieList.getcontZombiesMuertos() == 5 && nivel.equals(Level.HARD)) {
			fin = true;
		}
		else if(ZombieList.getcontZombiesMuertos() == 10 && nivel.equals(Level.INSANE)) {
			fin = true;
		}
		
		
		return fin;
	}
	public boolean seguirCreandoZombies() {
		boolean ok = false;
		if (getNumZombies() > 0) {
			ok = true;
		}	
		return ok;
	}
	
	public void mostrarHelp() {
		System.out.println("Add <plant> <x> <y>: Adds a plant in position x, y.");
		System.out.println("List: Prints the list of available plants.");
		System.out.println("Reset: Starts a new game.");
		System.out.println("Help: Prints this help message.");
		System.out.println("Exit: Terminates the program.");
		System.out.println("[none]: Skips cycle.");
	}
	
	public void mostrarList() {
		System.out.println("[S]unflower: Cost: 20 suncoins Harm: 0");
		System.out.println("[P]eashooter: Cost: 50 suncoins Harm: 1");
	}
	
	public boolean comprobarPosicion(int x, int y){
		boolean ok = false;
		if((0 <= x) && (x <= 3) && (y >= 0) && (y <= 7)) {
			ok = true;
		}
		return ok;
	}
	
	public SuncoinManager getSuncoin() {
		return this.suncoin;
	}
	public void restarVidaZombie(int x, int y){
		ZombieList.restarVida(x, y);
	}
	public void restarVidaSunflower(int x, int y){
		SunflowerList.restarVida(x, y);
	}
	public void restarVidaPeashooter(int x, int y){
		PeashooterList.restarVida(x, y);
	}
	
	public void stringGananZombies() {
		System.out.println("�GANAN LOS ZOMBIES!");
		System.out.println("TABLERO FINAL:");
		System.out.println("");
	}
	
	public void stringGananPlantas() {
		System.out.println("�GANAN LAS PLANTAS!");
		System.out.println("TABLERO FINAL:");
		System.out.println("");
	}
	
	public void crearZombie() {
		boolean creaZombie;
		creaZombie = zomManager.crearZombie(this.getRandom(), this.getNivel()) && this.vacio(zomManager.getPosX(this.getRandom(), this.getDimX()), this.getDimY());
		if(creaZombie) { // Comprueba que hay que crear zombie y que no se acabe de reiniciar el game
			if(this.seguirCreandoZombies()) {//Comprueba que queden zombies por crear
				this.crearZombie(zomManager.getPosX(this.getRandom(), this.getDimX())); //Crea el zombie
			}
		}
		this.update();
		
	}
	
	
}
