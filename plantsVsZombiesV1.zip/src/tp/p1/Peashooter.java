package tp.p1;


public class Peashooter {
	private int vida;
	private int da�o;
	private int frecuencia;
	private int fila;
	private int columna;
	private static int coste = 50;
	private Game game;
	
	public Peashooter(int fila, int columna, Game game)
	{
		this.columna = columna;
		this.da�o = 1;
		this.fila = fila;
		this.frecuencia = 1;
		this.vida = 3;
		this.setGame(game);
	}
	public int getVida() {
		return this.vida;
	}
	public int getFila() {
		return this.fila;
	}
	public int getColumna() {
		return this.columna;
	}
	public int getFrecuencia() {
		return this.frecuencia;
	}
	public int getDa�o() {
		return this.da�o;
	}
	
	public void setVida(int nuevaVida) {
		this.vida = nuevaVida;
	}
	public void setColumna(int nuevaColumna) {
		this.columna = nuevaColumna;
	}
	public void setFila(int nuevafila) {
		this.fila = nuevafila;
	}
	public static int getCoste() {
		return coste;
	}
	
	public Game getGame() {
		return game;
	}
	public void setGame(Game game) {
		this.game = game;
	}
	
	public void update() {
		int z;
		boolean ok = true;
		for(int j = columna+1; j < 8; j++)//recorremos toda la fila
		{
			z = game.buscaZombies(fila, j);// buscamos la pos del zombie
			if(z != -1 && ok) // atacamos
			{
				game.restarVidaZombie(fila, j);
				ok = false;
			}
		}
		
	}
	
	public String toString() {
		String stringPeashooter;
		stringPeashooter = "P [" + this.vida + "]";
		return stringPeashooter;
	}
	
}
