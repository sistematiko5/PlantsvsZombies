package tp.p1;

public class SunflowerList {
	private Sunflower SunflowerList[];
	private int contador;
	private Game game;
	
	public SunflowerList(Game game, int MAX_TAM_TABLERO) {
		SunflowerList = new Sunflower[MAX_TAM_TABLERO];
		this.contador = 0;
		this.game = game;
	}
	
	public boolean addSunflower(int fila, int columna)
	{
		boolean add = false;
		
		if(game.comprobarPosicion(fila, columna) && game.vacio(fila, columna)) {
			this.SunflowerList[this.contador] = new Sunflower(fila, columna, game);
			this.contador++;
			add = true;		
		}
		
		return add;
	}
	
	public void deleteSunflower(int posicion) {
		for (int i = posicion; i < contador; i++) {
			this.SunflowerList[i] = this.SunflowerList[i + 1];
		}
		this.contador--;
	}

	
	public Sunflower getSunFlower(int i) {
		return this.SunflowerList[i];
	}
	
	public int getCont()
	{
		return this.contador;
	}
	public void setCont(int num)
	{
		this.contador = num;
	}
	public void restarVida(int x, int y) {
		int pos;
		pos = buscaSunflowers(x, y);
		this.SunflowerList[pos].setVida(this.SunflowerList[pos].getVida() - 1);
		if(this.SunflowerList[pos].getVida() == 0){
			deleteSunflower(pos);
		}
	}
	
	public void update(){
		for(int i = 0; i < this.contador; ++i){
			this.SunflowerList[i].update();
		}
	}
	public int buscaSunflowers(int fila, int columna)
	{
		for(int i = 0; i< this.contador; i++)
		{
			if(this.SunflowerList[i].getColumna() == columna && this.SunflowerList[i].getFila() == fila)
			{
				return i;
			}
		}
		return -1;
	}
	
	public String getString(int pos) {
		return this.SunflowerList[pos].toString();
	}

}
