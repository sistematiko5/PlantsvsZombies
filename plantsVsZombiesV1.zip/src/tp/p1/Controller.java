package tp.p1;

public class Controller {
	private Game game;
	private String command;
	private CommandScanner commandScan = new CommandScanner();
	private GamePrinter printer;
	private int x, y;
	private boolean actualiza = false;
	
	public Controller(Game game, GamePrinter printer){
		this.game = game;
		this.printer = printer;
	}

	public void run() {
		commandScan.setCommand();
		command = commandScan.getCommand();
		while(command != "E" && !game.gananZombies() && !game.gananPlantas()) {
			switch(command) {
			case("A"):
				x = commandScan.getX();
				y = commandScan.getY();
				if (commandScan.getPlanta().equalsIgnoreCase("s")) {
					actualiza = game.addSunflower(x, y);
				}
				else if(commandScan.getPlanta().equalsIgnoreCase("p")){
					actualiza = game.addPeashooter(x, y);
				}
				if(actualiza == false) {
					System.out.println("Invalid command");
				}
				break;
			case("H"): //Muestra la ayuda
				game.mostrarHelp();
				actualiza = false;
				break;
			case("L"): //Muestra la lista de plantas
				game.mostrarList();			
				actualiza = false;
				break; 
			case("N"):	//Deja pasar un turno
				actualiza = true;
				break;
			case("R"): //Reinicializa el game
				game.reset();
				printer.printer(game, game.getDimX(), game.getDimY());
				actualiza = false;
				break;
			case("U"): //Por si el comando no es reconocido (Unknown)
				System.out.println("Invalid command");
				break;
			}
			if(actualiza) {
				game.crearZombie();//Comprueba si tiene que crear un zombie en ese ciclo
				if(!game.gananZombies() && !game.gananPlantas()) {//Comprueba que el juego no haya terminado
					printer.printer(game, game.getDimX(), game.getDimY());
				}
			}
			if(game.gananZombies()) {//Comprueba si ganan los zombies
				game.stringGananZombies();
				printer.printer(game, game.getDimX(), game.getDimY());
			}
			else if(game.gananPlantas()) {//Comprueba si ganan las plantas
				game.stringGananPlantas();
				printer.printer(game, game.getDimX(), game.getDimY());
			}
			else {//Si no se ha acabado sigue pidiendo commands
				commandScan.setCommand();
				command = commandScan.getCommand();
			}
			
		}
		
	}
	
}
